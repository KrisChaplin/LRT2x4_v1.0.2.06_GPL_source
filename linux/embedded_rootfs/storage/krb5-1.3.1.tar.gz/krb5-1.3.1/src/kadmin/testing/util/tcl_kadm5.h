
void Tcl_kadm5_init(Tcl_Interp *interp);
void Tcl_ovsec_kadm_init(Tcl_Interp *interp);

